<?php
include 'includes/db.php';

echo "Connected to the database successfully!";
?>
