<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

include 'includes/db.php';

$playlist_id = isset($_GET['playlist_id']) ? $_GET['playlist_id'] : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard - Studitify</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container">
        <h2 class="my-4">Playlists</h2>
        <div class="row">
            <?php
            $stmt = $pdo->query('SELECT * FROM playlists');
            while ($playlist = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo '<div class="col-md-4">';
                echo '<div class="card mb-4">';
                if ($playlist['image']) {
                    echo '<img src="' . $playlist['image'] . '" class="card-img-top" alt="Playlist Image">';
                }
                echo '<div class="card-body">';
                echo '<h5 class="card-title">' . htmlspecialchars($playlist['name']) . '</h5>';
                echo '<p class="card-text">' . htmlspecialchars($playlist['genre']) . '</p>';
                echo '<a href="dashboard.php?playlist_id=' . $playlist['id'] . '" class="btn btn-primary">View Songs</a>';
                echo '</div>';
                echo '</div>';
                echo '</div>';
            }
            ?>
        </div>

        <?php if ($playlist_id): ?>
            <h2 class="my-4">Songs in Playlist</h2>
            <div class="row">
                <?php
                $stmt = $pdo->prepare('SELECT * FROM songs WHERE playlist_id = ?');
                $stmt->execute([$playlist_id]);
                $songs = $stmt->fetchAll(PDO::FETCH_ASSOC);
                foreach ($songs as $song) {
                    echo '<div class="col-md-4">';
                    echo '<div class="card mb-4">';
                    if ($song['image']) {
                        echo '<img src="' . $song['image'] . '" class="card-img-top play-song" alt="Song Image" data-url="' . $song['url'] . '" data-title="' . htmlspecialchars($song['title']) . '" data-artist="' . htmlspecialchars($song['artist']) . '" data-genre="' . htmlspecialchars($song['genre']) . '" data-image="' . $song['image'] . '">';
                    }
                    echo '<div class="card-body">';
                    echo '<h5 class="card-title">' . htmlspecialchars($song['title']) . '</h5>';
                    echo '<p class="card-text">' . htmlspecialchars($song['artist']) . '</p>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
                ?>
            </div>
        <?php endif; ?>

        <!-- Modal -->
        <div class="modal fade" id="songModal" tabindex="-1" aria-labelledby="songModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="songModalLabel">Now Playing</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <img id="modal-song-image" src="" class="img-fluid" alt="Song Image">
                        <h5 id="modal-song-title"></h5>
                        <p id="modal-song-artist"></p>
                        <p id="modal-song-genre"></p>
                        <audio id="modal-audio-player" controls style="width: 100%;">
                            <source id="modal-audio-source" src="" type="audio/mpeg">
                            Your browser does not support the audio element.
                        </audio>
                        <div class="btn-group mt-3" role="group" aria-label="Media Controls">
                            <button type="button" class="btn btn-secondary" id="modal-prev-btn">Previous</button>
                            <button type="button" class="btn btn-secondary" id="modal-play-btn">Play</button>
                            <button type="button" class="btn btn-secondary" id="modal-pause-btn">Pause</button>
                            <button type="button" class="btn btn-secondary" id="modal-next-btn">Next</button>
                            <button type="button" class="btn btn-secondary" id="modal-loop-btn">Loop</button>
                            <button type="button" class="btn btn-secondary" id="modal-shuffle-btn">Shuffle</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const songImages = document.querySelectorAll('.play-song');
            const songModal = new bootstrap.Modal(document.getElementById('songModal'));
            const modalSongImage = document.getElementById('modal-song-image');
            const modalSongTitle = document.getElementById('modal-song-title');
            const modalSongArtist = document.getElementById('modal-song-artist');
            const modalSongGenre = document.getElementById('modal-song-genre');
            const modalAudioPlayer = document.getElementById('modal-audio-player');
            const modalAudioSource = document.getElementById('modal-audio-source');

            let currentSongIndex = 0;
            let shuffled = false;
            let shuffleOrder = [];
            const songs = <?php echo json_encode($songs); ?>;

            function playSong(index) {
                const song = songs[index];
                modalSongImage.src = song.image;
                modalSongTitle.textContent = song.title;
                modalSongArtist.textContent = song.artist;
                modalSongGenre.textContent = song.genre;
                modalAudioSource.src = song.url;
                modalAudioPlayer.load();
                modalAudioPlayer.play();
                currentSongIndex = index;
            }

            function nextSong() {
                if (shuffled) {
                    currentSongIndex = (currentSongIndex + 1) % shuffleOrder.length;
                    playSong(shuffleOrder[currentSongIndex]);
                } else {
                    currentSongIndex = (currentSongIndex + 1) % songs.length;
                    playSong(currentSongIndex);
                }
            }

            function prevSong() {
                if (shuffled) {
                    currentSongIndex = (currentSongIndex - 1 + shuffleOrder.length) % shuffleOrder.length;
                    playSong(shuffleOrder[currentSongIndex]);
                } else {
                    currentSongIndex = (currentSongIndex - 1 + songs.length) % songs.length;
                    playSong(currentSongIndex);
                }
            }

            function shuffleSongs() {
                shuffleOrder = Array.from({ length: songs.length }, (_, i) => i);
                for (let i = shuffleOrder.length - 1; i > 0; i--) {
                    const j = Math.floor(Math.random() * (i + 1));
                    [shuffleOrder[i], shuffleOrder[j]] = [shuffleOrder[j], shuffleOrder[i]];
                }
            }

            songImages.forEach((image, index) => {
                image.addEventListener('click', function () {
                    playSong(index);
                    songModal.show();
                });
            });

            document.getElementById('modal-play-btn').addEventListener('click', function () {
                modalAudioPlayer.play();
            });

            document.getElementById('modal-pause-btn').addEventListener('click', function () {
                modalAudioPlayer.pause();
            });

            document.getElementById('modal-prev-btn').addEventListener('click', function () {
                prevSong();
            });

            document.getElementById('modal-next-btn').addEventListener('click', function () {
                nextSong();
            });

            document.getElementById('modal-loop-btn').addEventListener('click', function () {
                modalAudioPlayer.loop = !modalAudioPlayer.loop;
                this.classList.toggle('active', modalAudioPlayer.loop);
            });

            document.getElementById('modal-shuffle-btn').addEventListener('click', function () {
                shuffled = !shuffled;
                if (shuffled) {
                    shuffleSongs();
                }
                this.classList.toggle('active', shuffled);
            });

            modalAudioPlayer.addEventListener('ended', function () {
                nextSong();
            });
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"></script>
<br><br><br>
</body>
</html>
