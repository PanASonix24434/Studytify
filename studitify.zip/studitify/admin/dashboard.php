<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Studitify</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container">
        <h2 class="my-4">Admin Dashboard</h2>
        <a href="manage_playlists.php" class="btn btn-primary mb-3">Manage Playlists</a>
        <a href="manage_songs.php" class="btn btn-primary mb-3">Manage Songs</a>
    </div>
    <?php include '../includes/footer.php'; ?>
</body>
</html>
