<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php');
    exit;
}

include '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_playlist'])) {
        $name = $_POST['name'];
        $genre = $_POST['genre'];
        $created_by = 'admin';

        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $image = 'uploads/' . basename($_FILES['image']['name']);
            move_uploaded_file($_FILES['image']['tmp_name'], '../' . $image);
        } else {
            $image = null;
        }

        $stmt = $pdo->prepare('INSERT INTO playlists (user_id, name, genre, created_by, image) VALUES (NULL, ?, ?, ?, ?)');
        $stmt->execute([$name, $genre, $created_by, $image]);
    } elseif (isset($_POST['update_playlist'])) {
        $id = $_POST['id'];
        $name = $_POST['name'];
        $genre = $_POST['genre'];

        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $image = 'uploads/' . basename($_FILES['image']['name']);
            move_uploaded_file($_FILES['image']['tmp_name'], '../' . $image);
            $stmt = $pdo->prepare('UPDATE playlists SET name = ?, genre = ?, image = ? WHERE id = ?');
            $stmt->execute([$name, $genre, $image, $id]);
        } else {
            $stmt = $pdo->prepare('UPDATE playlists SET name = ?, genre = ? WHERE id = ?');
            $stmt->execute([$name, $genre, $id]);
        }
    } elseif (isset($_POST['delete_playlist'])) {
        $id = $_POST['id'];
        // Manually delete associated songs first
        $stmt = $pdo->prepare('DELETE FROM songs WHERE playlist_id = ?');
        $stmt->execute([$id]);

        // Now delete the playlist
        $stmt = $pdo->prepare('DELETE FROM playlists WHERE id = ?');
        $stmt->execute([$id]);
    }
}

$playlists = $pdo->query('SELECT * FROM playlists')->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Playlists - Studitify</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <div class="container">
        <h2 class="my-4">Manage Playlists</h2>

        <a href="dashboard.php" class="btn btn-secondary mb-4">Back to Admin Dashboard</a>

        <form method="post" action="manage_playlists.php" enctype="multipart/form-data">
            <h3>Add Playlist</h3>
            <div class="mb-3">
                <label for="name" class="form-label">Playlist Name</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="mb-3">
                <label for="genre" class="form-label">Genre</label>
                <input type="text" class="form-control" id="genre" name="genre" required>
            </div>
            <div class="mb-3">
                <label for="image" class="form-label">Playlist Image</label>
                <input type="file" class="form-control" id="image" name="image" accept="image/*">
            </div>
            <button type="submit" class="btn btn-primary" name="add_playlist">Add Playlist</button>
        </form>

        <hr>

        <h3>Existing Playlists</h3>
        <div class="row">
            <?php foreach ($playlists as $playlist): ?>
                <div class="col-md-4">
                    <div class="card mb-4">
                        <?php if ($playlist['image']): ?>
                            <img src="../<?= $playlist['image'] ?>" class="card-img-top" alt="Playlist Image">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($playlist['name']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($playlist['genre']) ?></p>
                            <form method="post" action="manage_playlists.php" enctype="multipart/form-data">
                                <input type="hidden" name="id" value="<?= $playlist['id'] ?>">
                                <div class="mb-3">
                                    <label for="name-<?= $playlist['id'] ?>" class="form-label">Playlist Name</label>
                                    <input type="text" class="form-control" id="name-<?= $playlist['id'] ?>" name="name" value="<?= htmlspecialchars($playlist['name']) ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="genre-<?= $playlist['id'] ?>" class="form-label">Genre</label>
                                    <input type="text" class="form-control" id="genre-<?= $playlist['id'] ?>" name="genre" value="<?= htmlspecialchars($playlist['genre']) ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="image-<?= $playlist['id'] ?>" class="form-label">Playlist Image</label>
                                    <input type="file" class="form-control" id="image-<?= $playlist['id'] ?>" name="image" accept="image/*">
                                </div>
                                <button type="submit" class="btn btn-warning" name="update_playlist">Update Playlist</button>
                                <button type="submit" class="btn btn-danger" name="delete_playlist">Delete Playlist</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
<br><br><br>
    <?php include '../includes/footer.php'; ?>
</body>
</html>
