<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php');
    exit;
}

include '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_song'])) {
        $playlist_id = $_POST['playlist_id'];
        $title = $_POST['title'];
        $artist = $_POST['artist'];
        $genre = $_POST['genre'];

        if (isset($_FILES['song']) && $_FILES['song']['error'] == 0) {
            $url = 'uploads/' . basename($_FILES['song']['name']);
            move_uploaded_file($_FILES['song']['tmp_name'], '../' . $url);
        } else {
            $url = null;
        }

        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $image = 'uploads/' . basename($_FILES['image']['name']);
            move_uploaded_file($_FILES['image']['tmp_name'], '../' . $image);
        } else {
            $image = null;
        }

        $stmt = $pdo->prepare('INSERT INTO songs (playlist_id, title, artist, url, genre, image) VALUES (?, ?, ?, ?, ?, ?)');
        $stmt->execute([$playlist_id, $title, $artist, $url, $genre, $image]);
    } elseif (isset($_POST['update_song'])) {
        $id = $_POST['id'];
        $playlist_id = $_POST['playlist_id'];
        $title = $_POST['title'];
        $artist = $_POST['artist'];
        $genre = $_POST['genre'];

        if (isset($_FILES['song']) && $_FILES['song']['error'] == 0) {
            $url = 'uploads/' . basename($_FILES['song']['name']);
            move_uploaded_file($_FILES['song']['tmp_name'], '../' . $url);
            $stmt = $pdo->prepare('UPDATE songs SET playlist_id = ?, title = ?, artist = ?, url = ?, genre = ? WHERE id = ?');
            $stmt->execute([$playlist_id, $title, $artist, $url, $genre, $id]);
        } else {
            $stmt = $pdo->prepare('UPDATE songs SET playlist_id = ?, title = ?, artist = ?, genre = ? WHERE id = ?');
            $stmt->execute([$playlist_id, $title, $artist, $genre, $id]);
        }

        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $image = 'uploads/' . basename($_FILES['image']['name']);
            move_uploaded_file($_FILES['image']['tmp_name'], '../' . $image);
            $stmt = $pdo->prepare('UPDATE songs SET image = ? WHERE id = ?');
            $stmt->execute([$image, $id]);
        }
    } elseif (isset($_POST['delete_song'])) {
        $id = $_POST['id'];
        $stmt = $pdo->prepare('DELETE FROM songs WHERE id = ?');
        $stmt->execute([$id]);
    }
}

$songs = $pdo->query('SELECT songs.*, playlists.name AS playlist_name FROM songs JOIN playlists ON songs.playlist_id = playlists.id')->fetchAll(PDO::FETCH_ASSOC);
$playlists = $pdo->query('SELECT * FROM playlists')->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Songs - Studitify</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <div class="container">
        <h2 class="my-4">Manage Songs</h2>

        <a href="dashboard.php" class="btn btn-secondary mb-4">Back to Admin Dashboard</a>

        <form method="post" action="manage_songs.php" enctype="multipart/form-data">
            <h3>Add Song</h3>
            <div class="mb-3">
                <label for="playlist_id" class="form-label">Select Playlist</label>
                <select class="form-control" id="playlist_id" name="playlist_id" required>
                    <?php foreach ($playlists as $playlist): ?>
                        <option value="<?= $playlist['id'] ?>"><?= htmlspecialchars($playlist['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="title" class="form-label">Song Title</label>
                <input type="text" class="form-control" id="title" name="title" required>
            </div>
            <div class="mb-3">
                <label for="artist" class="form-label">Artist</label>
                <input type="text" class="form-control" id="artist" name="artist" required>
            </div>
            <div class="mb-3">
                <label for="genre" class="form-label">Genre</label>
                <input type="text" class="form-control" id="genre" name="genre" required>
            </div>
            <div class="mb-3">
                <label for="song" class="form-label">Song File</label>
                <input type="file" class="form-control" id="song" name="song" accept="audio/*" required>
            </div>
            <div class="mb-3">
                <label for="image" class="form-label">Song Image</label>
                <input type="file" class="form-control" id="image" name="image" accept="image/*">
            </div>
            <button type="submit" class="btn btn-primary" name="add_song">Add Song</button>
        </form>

        <hr>

        <h3>Existing Songs</h3>
        <div class="row">
            <?php foreach ($songs as $song): ?>
                <div class="col-md-4">
                    <div class="card mb-4">
                        <?php if ($song['image']): ?>
                            <img src="../<?= $song['image'] ?>" class="card-img-top" alt="Song Image">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($song['title']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($song['artist']) ?></p>
                            <p class="card-text">Playlist: <?= htmlspecialchars($song['playlist_name']) ?></p>
                            <form method="post" action="manage_songs.php" enctype="multipart/form-data">
                                <input type="hidden" name="id" value="<?= $song['id'] ?>">
                                <div class="mb-3">
                                    <label for="playlist_id-<?= $song['id'] ?>" class="form-label">Select Playlist</label>
                                    <select class="form-control" id="playlist_id-<?= $song['id'] ?>" name="playlist_id" required>
                                        <?php foreach ($playlists as $playlist): ?>
                                            <option value="<?= $playlist['id'] ?>" <?= $playlist['id'] == $song['playlist_id'] ? 'selected' : '' ?>><?= htmlspecialchars($playlist['name']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="title-<?= $song['id'] ?>" class="form-label">Song Title</label>
                                    <input type="text" class="form-control" id="title-<?= $song['id'] ?>" name="title" value="<?= htmlspecialchars($song['title']) ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="artist-<?= $song['id'] ?>" class="form-label">Artist</label>
                                    <input type="text" class="form-control" id="artist-<?= $song['id'] ?>" name="artist" value="<?= htmlspecialchars($song['artist']) ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="genre-<?= $song['id'] ?>" class="form-label">Genre</label>
                                    <input type="text" class="form-control" id="genre-<?= $song['id'] ?>" name="genre" value="<?= htmlspecialchars($song['genre']) ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="song-<?= $song['id'] ?>" class="form-label">Song File</label>
                                    <input type="file" class="form-control" id="song-<?= $song['id'] ?>" name="song" accept="audio/*">
                                </div>
                                <div class="mb-3">
                                    <label for="image-<?= $song['id'] ?>" class="form-label">Song Image</label>
                                    <input type="file" class="form-control" id="image-<?= $song['id'] ?>" name="image" accept="image/*">
                                </div>
                                <button type="submit" class="btn btn-warning" name="update_song">Update Song</button>
                                <button type="submit" class="btn btn-danger" name="delete_song">Delete Song</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
<br><br><br>
    <?php include '../includes/footer.php'; ?>
</body>
</html>
