<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

include '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $playlist_id = $_POST['playlist_id'];
    $title = $_POST['title'];
    $artist = $_POST['artist'];
    $genre = $_POST['genre'];

    // Handle the file upload
    if (isset($_FILES['song']) && $_FILES['song']['error'] == 0) {
        $url = 'uploads/' . basename($_FILES['song']['name']);
        move_uploaded_file($_FILES['song']['tmp_name'], '../' . $url);
    } else {
        $url = null;
    }

    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $image = 'uploads/' . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], '../' . $image);
    } else {
        $image = null;
    }

    $stmt = $pdo->prepare('INSERT INTO songs (playlist_id, title, artist, url, genre, image) VALUES (?, ?, ?, ?, ?, ?)');
    $stmt->execute([$playlist_id, $title, $artist, $url, $genre, $image]);

    header('Location: dashboard.php');
    exit();
}

// Get all playlists for the dropdown
$stmt = $pdo->query('SELECT * FROM playlists');
$playlists = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Song - Studitify</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container">
        <h2 class="my-4">Add Song</h2>
        <form method="post" action="add_song.php" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="playlist_id" class="form-label">Select Playlist</label>
                <select class="form-control" id="playlist_id" name="playlist_id" required>
                    <?php foreach ($playlists as $playlist): ?>
                        <option value="<?= $playlist['id'] ?>"><?= htmlspecialchars($playlist['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="title" class="form-label">Song Title</label>
                <input type="text" class="form-control" id="title" name="title" required>
            </div>
            <div class="mb-3">
                <label for="artist" class="form-label">Artist</label>
                <input type="text" class="form-control" id="artist" name="artist" required>
            </div>
            <div class="mb-3">
                <label for="genre" class="form-label">Genre</label>
                <input type="text" class="form-control" id="genre" name="genre" required>
            </div>
            <div class="mb-3">
                <label for="song" class="form-label">Song File</label>
                <input type="file" class="form-control" id="song" name="song" accept="audio/*" required>
            </div>
            <div class="mb-3">
                <label for="image" class="form-label">Song Image</label>
                <input type="file" class="form-control" id="image" name="image" accept="image/*">
            </div>
            <button type="submit" class="btn btn-primary">Add Song</button>
        </form>
<br><br><br><br>
    </div>
    <?php include '../includes/footer.php'; ?>
</body>
</html>
