<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Studitify</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container text-center my-5">
        <h1>Welcome to Studitify</h1>
        <p class="lead">A digital study platform that helps you focus on your study sessions with the help of music.</p>
        <a class="btn btn-primary" href="register.php">Get Started</a>
    </div>

    <?php include 'includes/footer.php'; ?>
</body>
</html>
