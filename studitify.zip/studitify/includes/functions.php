<?php
function getUserPlaylists($pdo, $user_id) {
    $stmt = $pdo->prepare('SELECT * FROM playlists WHERE user_id = ?');
    $stmt->execute([$user_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function createPlaylist($pdo, $user_id, $name) {
    $stmt = $pdo->prepare('INSERT INTO playlists (user_id, name) VALUES (?, ?)');
    $stmt->execute([$user_id, $name]);
}

function getAllPlaylists($pdo) {
    $stmt = $pdo->query('SELECT * FROM playlists');
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
