<footer class="footer mt-auto py-3 bg-light">
    <div class="container">
        <span class="text-muted">&copy; 2024 Studitify. All rights reserved.</span>
    </div>
</footer>
